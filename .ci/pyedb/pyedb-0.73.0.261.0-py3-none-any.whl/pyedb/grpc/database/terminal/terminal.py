# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

from typing import TYPE_CHECKING

from pyedb.generic.constants import BoundaryTypeMapper, SourceTermMapper, TerminalTypeMapper
from pyedb.grpc.database.inner.conn_obj import ConnObj

if TYPE_CHECKING:
    from pyedb.grpc.database.primitive.padstack_instance import PadstackInstance

from ansys.edb.core.terminal.edge_terminal import EdgeType as CoreEdgeType
from ansys.edb.core.terminal.terminal import (
    BoundaryType as CoreBoundaryType,
    TerminalType as CoreTerminalType,
)

from pyedb.grpc.database.primitive.primitive import Primitive
from pyedb.grpc.database.utility.port_post_processing_prop import PortPostProcessingProp
from pyedb.grpc.database.utility.value import Value
from pyedb.misc.decorators import deprecated_property


class Terminal(ConnObj):
    def __init__(self, pedb, core):
        super().__init__(pedb, core)
        self.core = core
        self._reference_object = None

        self.__terminal_type_mapping = {
            "invalid": None,
            "edge": CoreTerminalType.EDGE,
            "point": CoreTerminalType.POINT,
            "terminal_instance": CoreTerminalType.TERM_INST,
            "padstack_inst": CoreTerminalType.PADSTACK_INST,
            "bundle": CoreTerminalType.BUNDLE,
            "pin_group": CoreTerminalType.PIN_GROUP,
        }
        self.__boundary_type_mapping = {
            "port": CoreBoundaryType.PORT,
            "dc_terminal": CoreBoundaryType.DC_TERMINAL,
            "voltage_probe": CoreBoundaryType.VOLTAGE_PROBE,
            "voltage_source": CoreBoundaryType.VOLTAGE_SOURCE,
            "current_source": CoreBoundaryType.CURRENT_SOURCE,
            "rlc": CoreBoundaryType.RLC,
            "pec": CoreBoundaryType.PEC,
            "portboundary": CoreBoundaryType.PORT,
            "kdcterminal": CoreBoundaryType.DC_TERMINAL,
            "kvoltageprobe": CoreBoundaryType.VOLTAGE_PROBE,
            "kvoltagesource": CoreBoundaryType.VOLTAGE_SOURCE,
            "kcurrentsource": CoreBoundaryType.CURRENT_SOURCE,
            "rlcboundary": CoreBoundaryType.RLC,
            "pecboundary": CoreBoundaryType.PEC,
        }

    @property
    def net(self):
        """Terminal net.

        Returns
        -------
        :class:`Net <pyedb.grpc.database.net.net.Net>`
            Terminal Net object.

        """
        from pyedb.grpc.database.net.net import Net

        return Net(self._pedb, self.core.net)

    @property
    def port_post_processing_prop(self):
        return PortPostProcessingProp(self.core.port_post_processing_prop)

    @property
    def _hfss_port_property(self):
        """HFSS port property."""
        return self._hfss_properties

    @property
    def horizontal_extent_factor(self) -> float:
        """Horizontal extent factor.

        Returns
        -------
        float
            Extent value.
        """
        return self._hfss_port_property.horizontal_extent_factor

    @horizontal_extent_factor.setter
    def horizontal_extent_factor(self, value):
        p = self._hfss_port_property
        p.horizontal_extent_factor = value
        self._hfss_port_property = p

    @property
    def vertical_extent_factor(self) -> float:
        """Vertical extent factor.

        Returns
        -------
        float
            Vertical extent value.

        """
        return self._hfss_port_property.vertical_extent_factor

    @vertical_extent_factor.setter
    def vertical_extent_factor(self, value):
        p = self._hfss_port_property
        p.vertical_extent_factor = value
        self._hfss_port_property = p

    @property
    def pec_launch_width(self) -> str:
        """Launch width for the printed electronic component (PEC).

        Returns
        -------
        float
            Pec launch width value.
        """
        return self._hfss_port_property.pec_launch_width

    @pec_launch_width.setter
    def pec_launch_width(self, value):
        p = self._hfss_port_property
        p.pec_launch_width = value
        self._hfss_port_property = p

    @property
    def reference_layer(self):
        """Get layer of the terminal."""
        self._pedb.logger.error("Cannot determine terminal layer")
        return None

    @_hfss_port_property.setter
    def _hfss_port_property(self, value):
        self._hfss_properties = value

    @property
    def hfss_type(self) -> str:
        """HFSS port type."""
        return self._hfss_port_property.hfss_type

    @hfss_type.setter
    def hfss_type(self, value):
        p = self._hfss_port_property
        p.hfss_type = value
        self._hfss_port_property = p

    @property
    def do_renormalize(self) -> bool:
        """Determine whether port renormalization is enabled.

        Returns
        -------
        bool

        """
        return self.port_post_processing_prop.do_renormalize

    @do_renormalize.setter
    def do_renormalize(self, value):
        self.port_post_processing_prop.do_renormalize = value

    @property
    def do_deembed(self) -> bool:
        """Determine whether port deembed is enabled.
        Returns
        """
        return self.port_post_processing_prop.do_deembed

    @do_deembed.setter
    def do_deembed(self, value):
        self.port_post_processing_prop.do_deembed = value

    @property
    @deprecated_property("use do_deembed property instead")
    def deembed(self) -> bool:
        """Determine whether port deembed is enabled.

        .. deprecated:: 0.71.0
            The `deembed` property is deprecated. Please use `do_deembed` instead.
        """
        return self.port_post_processing_prop.do_deembed

    @deembed.setter
    def deembed(self, value):
        self.port_post_processing_prop.do_deembed = value

    @property
    def renormalization_impedance(self) -> float:
        """Get the renormalization impedance value.

        Returns
        -------
        float

        """
        return self.port_post_processing_prop.renormalization_impedance

    @renormalization_impedance.setter
    def renormalization_impedance(self, value):
        self.port_post_processing_prop.renormalization_impedance = value

    @property
    def net_name(self) -> str:
        """Net name.

        Returns
        -------
        str : name of the net.
        """
        if self.core.is_null:
            return ""
        elif self.core.net.is_null:
            return ""
        else:
            return self.core.net.name

    @net_name.setter
    def net_name(self, val):
        if not self.core.is_null and self.core.net.is_null:
            self.core.net.name = val

    @property
    def terminal_type(self) -> str | None:
        """Terminal Type. Accepted values for setter: `"edge"`, `"point"`, `"terminal_instance"`,
        `"padstack_instance"`, `"bundle_terminal"`, `"pin_group"`.

        Returns
        -------
        str
        """
        return TerminalTypeMapper.get_grpc(self.core.type.name)

    @terminal_type.setter
    def terminal_type(self, value):
        if isinstance(value, CoreTerminalType):
            self.core.type = value
        else:
            value = TerminalTypeMapper.get_grpc(value)
            if isinstance(value, str):
                value = self.__terminal_type_mapping.get(value, None)
            if not isinstance(value, CoreTerminalType):
                raise ValueError("Value must be a string or BoundaryType enum.")
            self.core.type = value

    @property
    def boundary_type(self) -> str:
        """Boundary type.

        Returns
        -------
        str
            port, pec, rlc, current_source, voltage_source, nexxim_ground, nexxim_pPort, dc_terminal, voltage_probe.
        """
        return BoundaryTypeMapper.get_grpc(self.core.boundary_type.name)

    @boundary_type.setter
    def boundary_type(self, value):
        if isinstance(value, CoreBoundaryType):
            self.core.boundary_type = value
        else:
            value = BoundaryTypeMapper.get_grpc(value)
            if isinstance(value, str):
                value = self.__boundary_type_mapping.get(value, None)
            if not isinstance(value, CoreBoundaryType):
                raise ValueError("Value must be a string or BoundaryType enum.")
            self.core.boundary_type = value

    @property
    def source_amplitude(self) -> float:
        """Source amplitude.

        Returns
        -------
        float : amplitude value.
        """
        return Value(self.core.source_amplitude)

    @source_amplitude.setter
    def source_amplitude(self, value):
        self.core.source_amplitude = value

    @property
    def source_phase(self) -> float:
        """Source phase.

        Returns
        -------
        float : phase value.
        """
        return Value(self.core.source_phase)

    @source_phase.setter
    def source_phase(self, value):
        self.core.source_phase = value

    @property
    def is_port(self) -> bool:
        """Whether it is a port.

        Returns
        -------
        bool

        """
        return True if self.boundary_type == "port" else False

    @property
    def is_current_source(self) -> bool:
        """Whether it is a current source.

        Returns
        -------
        bool

        """
        return True if self.boundary_type == "current_source" else False

    @property
    def is_voltage_source(self) -> bool:
        """Whether it is a voltage source.

        Returns
        -------
        bool

        """
        return True if self.boundary_type == "voltage_source" else False

    @property
    def impedance(self) -> float:
        """Impedance of the port.

        Returns
        -------
        float : impedance value.

        """
        return Value(self.core.impedance)

    @impedance.setter
    def impedance(self, value):
        self.core.impedance = self._pedb._value_setter(value)

    @property
    def reference_object(self) -> Primitive | PadstackInstance | bool:
        """This returns the object assigned as reference. It can be a primitive or a padstack instance.


        Returns
        -------
        :class:`PadstackInstance <pyedb.grpc.database.primitive.padstack_instance.PadstackInstance>` or
        :class:`Primitive <pyedb.grpc.database.primitive.primitives.Primitive>`
        """
        if not self._reference_object:
            if self.terminal_type == "edge":
                edges = self.core.edges
                edge_type = edges[0].type
                if edge_type == CoreEdgeType.PADSTACK:
                    self._reference_object = self.get_pad_edge_terminal_reference_pin()
                else:
                    self._reference_object = self.get_edge_terminal_reference_primitive()
            elif self.terminal_type == "pin_group":
                self._reference_object = self.get_pin_group_terminal_reference_pin()
            elif self.terminal_type == "point":
                self._reference_object = self.get_point_terminal_reference_primitive()
            elif self.terminal_type == "padstack_instance":
                self._reference_object = self.get_padstack_terminal_reference_pin()
            else:
                self._pedb.logger.warning("Invalid Terminal Type={}")
                return False

        return self._reference_object

    @property
    def reference_net_name(self) -> str:
        """Net name to which reference_object belongs.

        Returns
        -------
        str : net name.

        """
        if self.reference_object:
            return self.reference_object.net_name

        return ""

    def get_padstack_terminal_reference_pin(self, gnd_net_name_preference=None) -> PadstackInstance:
        """Get a list of pad stacks instances and serves Coax wave ports,
        pingroup terminals, PadEdge terminals.

        Parameters
        ----------
        gnd_net_name_preference : str, optional
            Preferred reference net name.

        Returns
        -------
        :class:`PadstackInstance <pyedb.grpc.database.primitive.padstack_instance.PadstackInstance>`
        """

        if self.core.is_circuit_port:
            return self.get_pin_group_terminal_reference_pin()
        _, padStackInstance, _ = self.core.get_parameters()

        # Get the pastack instance of the terminal
        pins = self._pedb.components.get_pin_from_component(self.core.component.name)
        return self._get_closest_pin(padStackInstance, pins, gnd_net_name_preference)

    def get_pin_group_terminal_reference_pin(self, gnd_net_name_preference=None) -> PadstackInstance | bool | None:
        """Return a list of pins and serves terminals connected to pingroups.

        Parameters
        ----------
        gnd_net_name_preference : str, optional
            Preferred reference net name.

        Returns
        -------
        :class:`PadstackInstance <pyedb.grpc.database.primitive.padstack_instance.PadstackInstance>`
        """

        ref_term = self.core.reference_terminal
        if self.core.type == CoreTerminalType.PIN_GROUP:
            padstack_instance = self.core.pin_group.pins[0]
            pingroup = ref_term.pin_group
            ref_pins = pingroup.pins
            return self._get_closest_pin(padstack_instance, ref_pins, gnd_net_name_preference)
        elif self.core.type == CoreTerminalType.PADSTACK_INST:
            _, padstack_instance, _ = self.core.get_parameters()
            if ref_term.type == CoreTerminalType.PIN_GROUP:
                pingroup = ref_term.pin_group
                ref_pins = pingroup.pins
                return self._get_closest_pin(padstack_instance, ref_pins, gnd_net_name_preference)
            else:
                try:
                    _, ref_term_psi, _ = ref_term.get_parameters()
                    return PadstackInstance(self._pedb, ref_term_psi)
                except AttributeError:
                    return False
        return False

    def get_edge_terminal_reference_primitive(self) -> Primitive | None:
        """Check and return a primitive instance that serves Edge ports,
        wave-ports and coupled-edge ports that are directly connected to primitives.

        Returns
        -------
        :class:`Primitive <pyedb.grpc.database.primitive.primitive.Primitive>`
        """
        # TODO check this method most likely does not work : issue #1903
        ref_layer = self.reference_layer
        edges = self.core.edges
        _, _, point_data = edges[0].get_parameters()
        layer_name = ref_layer.name
        for primitive in self._pedb.layout.primitives:
            if primitive.layer.name == layer_name:
                if primitive.polygon_data.point_in_polygon(point_data):
                    return Primitive(primitive, self._pedb)
        return None  # pragma: no cover

    def get_point_terminal_reference_primitive(self) -> Primitive | PadstackInstance | bool:
        """
        Find and return the primitive reference for the point terminal or the padstack instance.

        Returns
        -------
        Primitive or PadstackInstance
            The primitive reference for the point terminal or the padstack instance.
            Returns an instance of :class:`PadstackInstance
            <pyedb.grpc.database.primitive.padstack_instance.PadstackInstance>`
            or :class:`Primitive <pyedb.grpc.database.primitive.primitive.Primitive>`.
        """

        ref_term = self.core.reference_terminal  # return value is type terminal
        _, point_data, layer = ref_term.get_parameters()
        layer_name = layer.name
        for primitive in self._pedb.layout.primitives:
            if primitive.layer.name == layer_name:
                if primitive.polygon_data.point_in_polygon(point_data):
                    return Primitive(self._pedb, primitive)
        for vias in self._pedb.padstacks.instances.values():
            if layer_name in vias.layer_range_names:
                plane = self._pedb.modeler.Shape(
                    "rectangle", pointA=vias.position, pointB=vias.padstack_definition.bounding_box[1]
                )
                rectangle_data = vias._pedb.modeler.shape_to_polygon_data(plane)
                if rectangle_data.point_in_polygon(point_data):
                    return vias
        return False

    def get_pad_edge_terminal_reference_pin(self, gnd_net_name_preference=None) -> PadstackInstance:
        """Get the closest pin padstack instances and serves any edge terminal connected to a pad.

        Parameters
        ----------
        gnd_net_name_preference : str, optional
            Preferred reference net name. Optianal, default is `None` which will auto compute the gnd name.

        Returns
        -------
        :class:`PadstackInstance <pyedb.grpc.database.primitive.padstack_instance.PadstackInstance>`
        """
        comp_inst = self.core.component
        pins = self._pedb.components.get_pin_from_component(comp_inst.name)
        edges = self.core.edges
        _, pad_edge_pstack_inst, _, _ = edges[0].get_parameters()
        return self._get_closest_pin(pad_edge_pstack_inst, pins, gnd_net_name_preference)

    def _get_closest_pin(self, ref_pin, pin_list, gnd_net=None):
        _, pad_stack_inst_point, _ = ref_pin.position_and_rotation  # get the xy of the padstack
        if gnd_net is not None:
            power_ground_net_names = [gnd_net]
        else:
            power_ground_net_names = [net for net in self._pedb.nets.power.keys()]
        comp_ref_pins = [i for i in pin_list if i.net.name in power_ground_net_names]
        if len(comp_ref_pins) == 0:  # pragma: no cover
            self._pedb.logger.error(
                "Terminal with PadStack Instance Name {} component has no reference pins.".format(ref_pin.GetName())
            )
            return None
        closest_pin_distance = None
        pin_obj = None
        for pin in comp_ref_pins:  # find the distance to all the pins to the terminal pin
            if pin.name == ref_pin.name:  # skip the reference psi
                continue  # pragma: no cover
            _, pin_point, _ = pin.position_and_rotation
            distance = pad_stack_inst_point.distance(pin_point)
            if closest_pin_distance is None:
                closest_pin_distance = distance
                pin_obj = pin
            elif closest_pin_distance < distance:
                continue
            else:
                closest_pin_distance = distance
                pin_obj = pin
        if pin_obj:
            return PadstackInstance(self._pedb.pin_obj)

    @property
    def magnitude(self) -> float:
        """Get the magnitude of the source.

        Returns
        -------
        float : source magnitude.
        """
        return Value(self.core.source_amplitude)

    @magnitude.setter
    def magnitude(self, value):
        self.core.source_amplitude = self._pedb._value_setter(value)

    @property
    def phase(self) -> float:
        """Get the phase of the source.

        Returns
        -------
        float : source phase.

        """
        return Value(self.core.source_phase)

    @phase.setter
    def phase(self, value):
        self.core.source_phase = self._pedb._value_setter(value)

    @property
    def terminal_to_ground(self):
        return SourceTermMapper.get_grpc(self.core.term_to_ground.name)

    @terminal_to_ground.setter
    def terminal_to_ground(self, value):
        map_val = SourceTermMapper.get_grpc(value)

        self.core.term_to_ground = getattr(self.core.term_to_ground, map_val.upper())

    @property
    def reference_terminal(self):
        """Return reference terminal.

        Returns
        -------
        PadstackInstanceTerminal
            Reference terminal object.
        """
        if self.core.reference_terminal:
            return self._pedb.terminals[self.core.reference_terminal.name]
        else:
            return None

    @reference_terminal.setter
    def reference_terminal(self, value):
        try:
            self.core.reference_terminal = value.core
        except AttributeError:
            raise ValueError("Failed to set reference terminal.")

    @property
    def name(self):
        """Terminal name."""
        return self.core.name

    @name.setter
    def name(self, value):
        self.core.name = value

    @property
    def is_circuit_port(self) -> bool:
        """Whether the terminal is a circuit port.

        Returns
        -------
        bool

        """
        if hasattr(self.core, "is_circuit_port"):
            return self.core.is_circuit_port
        return False

    @is_circuit_port.setter
    def is_circuit_port(self, value):
        if hasattr(self.core, "is_circuit_port"):
            self.core.is_circuit_port = value
        else:
            self._pedb.logger.warning("Terminal does not support circuit port property.")

    @property
    @deprecated_property("use is_circuit_port property instead")
    def is_circuit(self) -> bool:
        """Check if the terminal is a circuit terminal.

        .. deprecated:: 0.70.0
           use :attr: `is_circuit` property is deprecated. Please use `is_circuit_port` instead.

        Returns
        -------
        bool
            True if the terminal is a circuit terminal, False otherwise.
        """
        return self.is_circuit_port

    @is_circuit.setter
    @deprecated_property("use is_circuit_port property instead")
    def is_circuit(self, value: bool):
        """Set whether the terminal is a circuit terminal.

        .. deprecated:: 0.70.0
           Use :attr: `is_circuit` property is deprecated. Please use `is_circuit_port` instead.

        Parameters
        ----------
        value : bool
            True to set the terminal as a circuit terminal, False otherwise.
        """
        self.is_circuit_port = value
