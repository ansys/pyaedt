# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from typing import TYPE_CHECKING, Union

from pyedb.misc.decorators import deprecated

if TYPE_CHECKING:
    from ansys.edb.core.simulation_setup.simulation_setup import SimulationSetup as CoreSimulationSetup

from ansys.edb.core.simulation_setup.simulation_setup import SimulationSetupType as CoreSimulationSetupType

from pyedb.grpc.database.simulation_setup.sweep_data import SweepData

_mapping_simulation_types = {
    CoreSimulationSetupType.HFSS: "hfss",
    CoreSimulationSetupType.SI_WAVE: "siwave",
    CoreSimulationSetupType.SI_WAVE_DCIR: "siwave_dcir",
    CoreSimulationSetupType.HFSS_PI: "hfss_pi",
    CoreSimulationSetupType.RAPTOR_X: "raptor_x",
    CoreSimulationSetupType.Q3D_SIM: "q3d",
}


class SimulationSetupDeprecated:
    @property
    def type(self):
        return self.setup_type

    @property
    def sweeps(self):
        return {i.name: i for i in self.sweep_data}

    @property
    def frequency_sweeps(self):
        return self.sweeps


class SimulationSetup(SimulationSetupDeprecated):
    def __init__(self, pedb, core: "CoreSimulationSetup"):
        """PyEDB Simulation Setup base class."""
        self.core = core
        self._pedb = pedb

    def cast(self):
        """Cast a core SimulationSetup to PyEDB SimulationSetup."""
        return self.core.cast()

    @property
    def id(self) -> int:
        """Unique ID of the EDB object.

        Returns
        -------
        int
            Simulation setup ID.
        """
        return self.core.id

    @property
    def is_null(self) -> bool:
        """Check if the simulation setup is null.

        Returns
        -------
        bool
            True if the simulation setup is null, False otherwise.
        """
        return self.core.is_null

    @property
    def name(self) -> str:
        """Get or set the name of the simulation setup.

        Returns
        -------
        str
            Simulation setup name.
        """
        return self.core.name

    @name.setter
    def name(self, value: str):
        self.core.name = value

    @property
    def position(self) -> int:
        """Get or set the position of the simulation setup.

        Returns
        -------
        int
            Simulation setup position.
        """
        return self.core.position

    @position.setter
    def position(self, value: int):
        self.core.position = value

    @property
    def sweep_data(self) -> list[SweepData]:
        """Get the sweep data associated with the simulation setup.

        Returns
        -------
        list[SweepData]
            List of sweep data objects.
        """

        return [SweepData(self._pedb, core=sweep, simsetup=self) for sweep in self.core.sweep_data]

    @sweep_data.setter
    def sweep_data(self, sweeps: list[SweepData]):
        self.core.sweep_data = [sweep.core for sweep in sweeps]

    def _normalize_distribution(self, distribution: str) -> str:
        """Normalize user-provided distribution string to internal code.

        Parameters
        ----------
        distribution : str
            User-specified distribution.

        Returns
        -------
        str
            One of: "LIN", "LINC", "ESTP", "DEC", "OCT".
        """
        if not distribution:
            return "LIN"
        d = distribution.lower().strip()
        if d in ("linear", "linear scale"):
            return "LIN"
        if d in ("linear_count", "linear count"):
            return "LINC"
        if d == "exponential":
            return "ESTP"
        if d in ("decade_count", "decade count", "log scale", "log_scale"):
            return "DEC"
        if d in ("octave_count", "octave count"):
            return "OCT"
        # already an internal code?
        if d.upper() in ("LIN", "LINC", "ESTP", "DEC", "OCT"):
            return d.upper()
        return "LIN"

    def _build_sweep_from_params(
        self, name: str, distribution: str, start_freq, stop_freq, step, discrete: bool
    ) -> SweepData:
        """Construct a SweepData object from normalized parameters."""
        start_freq_val = self._pedb.number_with_units(start_freq, "Hz")
        stop_freq_val = self._pedb.number_with_units(stop_freq, "Hz")
        step_val = str(step)
        sweep = SweepData(
            self._pedb,
            name=name,
            distribution=distribution,
            start_f=start_freq_val,
            end_f=stop_freq_val,
            step=step_val,
            simsetup=self,
        )
        if discrete:
            # Use the string-based setter to avoid direct enum access
            sweep.type = "discrete"
        return sweep

    def _add_sweeps_from_frequency_set(self, frequency_set, name, init_sweep_count, discrete):
        """Handle the legacy frequency_set format.

        This function creates SweepData entries from the provided frequency_set and
        appends them to the existing core.sweep_data.
        """
        from pyedb.grpc.database.simulation_setup.sweep_data import _mapping_distribution

        sw_data = None
        for sweep_item in frequency_set:
            # detect distribution token and map to internal code
            if "linear_scale" in sweep_item:
                distribution = "LIN"
            elif "linear_count" in sweep_item:
                distribution = "LINC"
            elif "exponential" in sweep_item:
                distribution = "ESTP"
            elif "log_scale" in sweep_item:
                distribution = "DEC"
            elif "octave_count" in sweep_item:
                distribution = "OCT"
            else:
                distribution = "LIN"

            start_freq = self._pedb.number_with_units(sweep_item[1], "Hz")
            stop_freq = self._pedb.number_with_units(sweep_item[2], "Hz")
            step = str(sweep_item[3])
            if not name:
                name = f"sweep_{init_sweep_count + 1}"
            if not sw_data:
                sw_data = SweepData(
                    self._pedb,
                    name=name,
                    distribution=distribution,
                    start_f=start_freq,
                    end_f=stop_freq,
                    step=step,
                    simsetup=self,
                )
            else:
                sw_data.add_frequency_data(distribution=distribution, start_f=start_freq, end_f=stop_freq, step=step)
        if discrete:
            # Use the string-based setter
            sw_data.type = "discrete" if discrete else "interpolating"
        # append existing core sweep data (preserve previous entries)
        self.core.sweep_data = self.core.sweep_data + [sw_data.core]
        return sw_data

    def _add_single_sweep(self, sweep: SweepData) -> Union[SweepData, None]:
        """Insert a single sweep into core.sweep_data preserving existing sweeps.

        Returns the newly added SweepData on success, None otherwise.
        """
        self.core.sweep_data = self.core.sweep_data + [sweep.core]
        return self.sweep_data[-1]

    @deprecated("use add_sweep method instead")
    def add_frequency_sweep(self, frequency_sweep: list[str]):
        """This method is deprecated. Please use 'add_sweep' with appropriate parameters instead."""
        # converting frequency sweep to frequency set
        mapping_distribution = {
            "LIN": "linear_scale",
            "LINC": "linear_count",
            "ESTP": "exponential",
            "DEC": "log_scale",
            "OCT": "octave_count",
        }
        frequency_sweep[0] = mapping_distribution[self._normalize_distribution(frequency_sweep[0])]
        self.add_sweep(
            distribution=frequency_sweep[0],
            start_freq=frequency_sweep[1],
            stop_freq=frequency_sweep[2],
            step=frequency_sweep[3],
        )

    def add_sweep(
        self,
        name: str | None = None,
        distribution: str = "linear",
        start_freq: str | float = "0GHz",
        stop_freq: str | float = "20GHz",
        step: str | float = "10MHz",
        discrete: bool = False,
        frequency_set: list[list[str]] | None = None,
    ) -> SweepData | None:
        """Add a HFSS frequency sweep.

        This method was refactored to reduce complexity. The behavior is compatible
        with the previous implementation: it accepts either a legacy `frequency_set`
        or single-sweep parameters.

        Parameters
        ----------
        name: str
            sweep name
        distribution: str
            sweep distribution. Supported values `"linear"`, `"linear_count"`, `"decade_count"`, `"exponential"`,
            `"octave_count"`. Default: `"linear"`
        start_freq: str or float
            starting frequency (e.g. "0GHz" or 0)
        stop_freq: str or float
            stopping frequency (e.g. "20GHz" or 20000000000)
        step: str or float
            frequency step (e.g. "10MHz" or 10000000)
        discrete: bool
            whether the sweep is discrete or interpolating
        frequency_set: list[list[str]] or None
            legacy multi-sweep format (e.g. [["linear_scale", "0GHz", "20GHz", "10MHz"], [...], ...])

        Returns
        -------
        SweepData | None
            The newly added sweep when single sweep parameters are used, or None when
            `frequency_set` is provided (legacy multi-sweep behavior).
        """
        # Legacy batch mode
        if frequency_set:
            return self._add_sweeps_from_frequency_set(frequency_set, name, len(self.sweep_data), discrete)

        # Single-sweep mode delegated to helper to reduce complexity
        distribution_code = self._normalize_distribution(distribution)
        if not name:
            name = f"sweep_{len(self.sweep_data) + 1}"

        sweep = self._build_sweep_from_params(name, distribution_code, start_freq, stop_freq, step, discrete)
        result = self._add_single_sweep(sweep)
        if result:
            return result
        self._pedb.logger.error("Failed to add frequency sweep data")
        return None

    def clear_sweeps(self):
        """Clear all frequency sweeps from the simulation setup."""
        self.core.sweep_data = []

    @property
    def setup_type(self) -> str:
        """Get the type of the simulation setup.

        Returns
        -------
        str
            Simulation setup type.
        """
        return _mapping_simulation_types[self.core.type]
